# FireSide-Laravel
The Laravel side of the code that controls sending emails, creating draft orders.


# README #

This README includes valuable information on how to set up the certbot (Digital Ocean) to be sure your installation is using SSL. [ https://www.digitalocean.com/community/tutorials/how-to-secure-nginx-with-let-s-encrypt-on-ubuntu-22-04 ]

This README also includes information on how to find and replace email addresses and code updates.

### What is this repository for? ###

* Fireside Hearth and Home

### How do I get set up? ###

* Certbot Setup
* Configuration
* Dependencies
* Database configuration
* How to run tests
* Deployment instructions

* Setting up Laravel
* Drop in the repo
* Reboot

### What if I don't have a LAMP (Linux, Apache, MySQL, PHP) Server installed on my server/droplet/webspace ###

* LAMP Install instructions below

### Who do I talk to about problems with this installation? ###

* donnie@brandography.com or David@brandography.com
* chad@brandography.com

## Certbot Setup ###

When setting up the bot (copy/paste each in to their own line hitting enter/return after each one and waiting for each to finish before moving on to the next line:
Login to the console or through SSH console as root (or your username and pass if you have one.)
/* Installing Certbot */
sudo snap install core; sudo snap refresh core
sudo apt remove certbot
sudo snap install --classic certbot
sudo ln -s /snap/bin/certbot /usr/bin/certbot
/* Confirming Nginx’s Configuration */
sudo nano /etc/nginx/sites-available/YOUR.COM_DOMAIN
server_name YOUR.COM_DOMAIN www.YOUR.COM_DOMAIN;
sudo nginx -t
sudo systemctl reload nginx
/* Allowing HTTPS Through the Firewall */
sudo ufw status
sudo ufw allow 'Nginx Full'
sudo ufw delete allow 'Nginx HTTP'
sudo ufw status
/* Obtaining an SSL Certificate */
sudo certbot --nginx -d YOUR.COM_DOMAIN -d www.YOUR.COM_DOMAIN
/*  Verifying Certbot Auto-Renewal */
sudo systemctl status snap.certbot.renew.service
sudo certbot renew --dry-run


## Certbot Setup ###

Install Laravel

Laravel utilizes Composer ( https://getcomposer.org/ )to manage its dependencies. First, download a copy of the 
composer.phar. Once you have the PHAR archive, you can either keep it in your local project directory or move 
to usr/local/bin to use it globally on your system. 

Download Laravel through Composer (Simpliest way.)

composer global require "laravel/installer=~1.1"

Make sure to place the ~/.composer/vendor/bin directory in your PATH so the laravel executable is found when you 
run the laravel command in your terminal.

Once installed, the simple laravel new command 
will create a fresh Laravel installation in the directory you specify. For 
instance, laravel new blog would create a directory named blog containing a fresh 
Laravel installation with all dependencies installed. This method of installation is much 
faster than installing via Composer.

composer create-project laravel/laravel {directory} 4.2 --prefer-dist

Once Composer is installed, download the 4.2 version ( https://getcomposer.org/ ) of the Laravel framework 
and extract its contents into a directory on your server. Next, in the root of your Laravel application, 
run the php composer.phar install (or composer install) command to install all of the framework's dependencies. 
This process requires Git to be installed on the server to successfully complete the installation.

If you want to update the Laravel framework, you may issue the php composer.phar update command.

The Laravel framework has a few system requirements:

PHP >= 5.4
MCrypt PHP Extension
As of PHP 5.5, some OS distributions may require you to manually install the PHP JSON extension. When using 
Ubuntu, this can be done via 

apt-get install php5-json

The first thing you should do after installing Laravel is set your application key to a random string. If you 
installed Laravel via Composer, this key has probably already been set for you by the key:generate command. Typically, 
this string should be 32 characters long. The key can be set in the app.php configuration file. If the application key is 
not set, your user sessions and other encrypted data will not be secure.

Laravel needs almost no other configuration out of the box. You are free to get started developing! However, 
you may wish to review the app/config/app.php file and its documentation. It contains several options such as timezone 
and locale that you may wish to change according to your application.

Once Laravel is installed, you should also configure your local environment. This will allow you to receive 
detailed error messages when developing on your local machine. By default, detailed error reporting is disabled in 
your production configuration file.

Note: You should never have app.debug set to true for a production application. 

Never, ever do it.

Laravel may require one set of permissions to be configured: folders within app/storage require write access by the 
web server.

Several of the framework directory paths are configurable. To change the location of these directories, check 
out the bootstrap/paths.php file.

Apache
The framework ships with a public/.htaccess file that is used to allow URLs without index.php. If you use Apache 
to serve your Laravel application, be sure to enable the mod_rewrite module.

If the .htaccess file that ships with Laravel does not work with your Apache installation, try this one:

Options +FollowSymLinks
RewriteEngine On
 
RewriteCond %{REQUEST_FILENAME} !-d
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^ index.php [L]

Nginx
On Nginx, the following directive in your site configuration will allow "pretty" URLs:

location / {
    try_files $uri $uri/ /index.php?$query_string;
}

Navigate to the www folder and drop the folders in the www in to that folder.
Restart the server

sudo reboot;


### LAMP SETUP Step by Step Assuming Ubuntu 20.04 ### 

Follow each step by copy/pasting them on a line of thier own and hitting Enter/Return after and waiting for the 
commands to finish before pasting the next step.

Update your packages and distro first!!

sudo apt update
sudo apt upgrade

Now open ports 22 (for SSH), 80 and 443 and enable Ubuntu Firewall (ufw):


sudo ufw allow ssh
sudo ufw allow 80
sudo ufw allow 443
sudo ufw enable

Installing and testing Apache2
Install Apache using apt:

sudo apt install apache2
sudo systemctl status apache2

Once installed, test by accessing your server’s IP in your browser:

http://YOURSERVERIPADDRESS/

sudo apt install php7.4 php7.4-mysql php-common php7.4-cli php7.4-json php7.4-common php7.4-opcache libapache2-mod-php7.4

Check the installation and version:

php --version

Restart Apache for the changes to take effect:

sudo systemctl restart apache2
Create a phpinfo.php test page:

echo '<?php phpinfo(); ?>' | sudo tee -a /var/www/html/phpinfo.php > /dev/null

Test everything is working by accessing the following in your browser:

http://YOURSERVERIPADDRESS/phpinfo.php

Once you’ve confirmed that PHP is working correctly, delete the test file.

sudo rm /var/www/html/phpinfo.php


/* INSTALL MYSQL */

sudo apt update
sudo apt install mysql-server
sudo systemctl start mysql.service

/* Configure MySQL */

sudo mysql
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'password';
exit
mysql -u root -p
ALTER USER 'root'@'localhost' IDENTIFIED WITH auth_socket;
sudo mysql_secure_installation

/* Create Database and a user */
sudo mysql
mysql -u root -p
CREATE USER 'username'@'host' IDENTIFIED WITH authentication_plugin BY 'password';
CREATE USER 'YOURUSERNAME'@'localhost' IDENTIFIED BY 'password';
CREATE USER 'YOURUSERNAME'@'localhost' IDENTIFIED WITH mysql_native_password BY 'password';
ALTER USER 'YOURUSERNAME'@'localhost' IDENTIFIED WITH mysql_native_password BY 'password';
GRANT PRIVILEGE ON database.table TO 'username'@'host';
GRANT CREATE, ALTER, DROP, INSERT, UPDATE, INDEX, DELETE, SELECT, REFERENCES, RELOAD on *.* TO 'YOURUSERNAME'@'localhost' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON *.* TO 'YOURUSERNAME'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;
exit
mysql -u YOURUSERNAME -p

/* Testing MYSQL */

systemctl status mysql.service
sudo mysqladmin -p -u YOURUSERNAME version


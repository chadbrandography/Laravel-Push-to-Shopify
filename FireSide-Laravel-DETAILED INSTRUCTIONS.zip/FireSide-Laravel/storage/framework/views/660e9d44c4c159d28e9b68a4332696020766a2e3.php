<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="utf-8">
</head>
<body>
    <h2>Fireside Lead</h2>
    <?php if(isset($data)): ?>
    <div>

        <p>
            <strong>First Name: </strong><?php echo e($data['first_name']); ?><br />
            <strong>Last Name: </strong><?php echo e($data['last_name']); ?><br />
            <strong>Email: </strong><?php echo e($data['email']); ?><br />
            <strong>Phone: </strong><?php echo e($data['phone']); ?><br />
            <strong>Address: </strong><?php echo e($data['address1']); ?><br />
            <strong>City: </strong><?php echo e($data['city']); ?><br />
            <strong>State: </strong><?php echo e($data['state']); ?><br />
            <strong>Zip: </strong><?php echo e($data['zip']); ?><br />
            <strong>Lead Type: </strong><?php echo e($data['ima']); ?><br />
            <strong>Project Type: </strong><?php echo e($data['projectType']); ?><br />
            <strong>Project Timeline: </strong><?php echo e((isset($data['projectTimeline'])) ? $data['projectTimeline'] : "N/A"); ?><br />
            <strong>Project Details: </strong><?php echo e($data['projectDetails']); ?><br />
            <strong>Contractor Name(if applicable): </strong><?php echo e($data['contactorName']); ?><br />
            <strong>Company Name(if applicable): </strong><?php echo e($data['companyName']); ?><br />
        </p>

    </div>
    <?php endif; ?>
</body>
</html><?php /**PATH /var/www/html/resources/views/email.blade.php ENDPATH**/ ?>
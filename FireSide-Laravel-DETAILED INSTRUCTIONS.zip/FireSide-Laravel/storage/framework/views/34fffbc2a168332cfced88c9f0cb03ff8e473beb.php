<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="utf-8">
</head>
<body>
    <h2>New Draft Order</h2>
    <?php if(isset($data)): ?>
    <div>
        <p>
            A New Draft Order has been created for: <br />
            <strong>First Name: </strong><?php echo e($data['first_name']); ?><br />
            <strong>Last Name: </strong><?php echo e($data['last_name']); ?><br />
            <strong>Email: </strong><?php echo e($data['email']); ?><br />
            <strong>Phone: </strong><?php echo e($data['phone']); ?><br />
            <strong>Address: </strong><?php echo e($data['address1']); ?><br />
            <strong>City: </strong><?php echo e($data['city']); ?><br />
            <strong>State: </strong><?php echo e($data['state']); ?><br />
            <strong>Zip: </strong><?php echo e($data['zip']); ?><br />
            <strong>Purchase Order Number: </strong><?php echo e($data['po_number']); ?><br />
        </p>

    </div>
    <?php endif; ?>
</body>
</html><?php /**PATH /var/www/html/resources/views/email-basic.blade.php ENDPATH**/ ?>
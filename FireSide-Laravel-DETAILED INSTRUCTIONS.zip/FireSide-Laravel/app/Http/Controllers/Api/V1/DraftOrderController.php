<?php
namespace App\Http\Controllers\Api\V1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Shopify\Context;
use Shopify\Auth\FileSessionStorage;
use Shopify\Clients\Rest;
use App\Helpers\ShopifyApi;
use App\Helpers\FiresideLead;
use App\Helpers\QualificationTargetsNotifications;

class DraftOrderController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = $request->all();
        $shopifyStore = $input['shopify_store'];
        $email = $input['email'];

        $shopifyStoreUrl = config('app.' . $shopifyStore . '_shopify_url');
        $accessToken = config('app.' . $shopifyStore . '_shopify_access_token');
        $apiKey = config('app.' . $shopifyStore . '_shopify_api_key');
        $apiSecret = config('app.' . $shopifyStore . '_shopify_api_secret_key');
        $apiVersion = config('app.' . $shopifyStore . '_api_version');

        (new ShopifyApi())->setShopifyContext($apiKey, $apiSecret, $shopifyStoreUrl, $apiVersion);

        $customer = $this->findCustomer($email, $shopifyStoreUrl, $accessToken);

        $customerId = null;
        $message = "";
        if($customer == null) {
            $customerId = $this->createCustomer($input, $shopifyStoreUrl, $accessToken);
            $message .= "Customer Created, ";
        } else {
            $customerId = $customer['id'];
            $message .= "Customer Found, ";
        }
        if($customerId == null) {
            $message .= "Could not find/create customer, ";
        } else {
            //create draft order
            $message .= $this->createDraftOrder($input, $customerId, $shopifyStoreUrl, $accessToken);
        }

        if($shopifyStore == "fireside") {
            (new FiresideLead())->submitLead($input);
        }

        if($shopifyStore == "qualification_targets") {
            (new QualificationTargetsNotifications())->sendNotification($input);
        }

        return response()->json([
            'message' => $message,
            'shopify_store' => $shopifyStore,
            'shopify_store_url' => $shopifyStoreUrl,
        ]);
    }

    public function createDraftOrder($input, $customerId, $shopifyStoreUrl, $accessToken)
    {
        $message = "";

        $lineItems = [];
        foreach($input["line_items"] as $line_item) {
            $variantId = $line_item[0];
            $quantity = $line_item[1];

            $lineItem = new \stdClass();
            $lineItem->variant_id = $variantId;
            $lineItem->quantity = $quantity;
            array_push($lineItems, $lineItem);
        }

        $client = new Rest($shopifyStoreUrl, $accessToken);
        $response = $client->post(
        "draft_orders",
            [
                "draft_order" => [
                    "line_items" => $lineItems,
                    "customer" => [
                        "id" => $customerId
                    ],
                ]
            ]
        );

        $message = "Draft Order " . $response->getReasonPhrase() . ", ";

        return $message;
    }

    public function createCustomer($input, $shopifyStoreUrl, $accessToken)
    {
        $firstName = $input['first_name'];
        $lastName = $input['last_name'];
        $email = $input['email'];
        $phone = (isset($input['phone'])) ? $input['phone'] : "";
        $verifiedEmail = $input['verified_email'];

        $addresses = [];
        $address = new \stdClass();
        $address->address1 = $input['address1'];
        $address->city = $input['city'];
        $address->state = $input['state'];
        $address->phone = $phone;
        $address->zip = $input['zip'];
        $address->first_name = $firstName;
        $address->last_name = $lastName;
        array_push($addresses, $address);

        $customerId = null;
        $client = new Rest($shopifyStoreUrl, $accessToken);
        $response = $client->post(
        "customers",
            [
                "customer" => [
                    "first_name" => $firstName,
                    "last_name" => $lastName,
                    "email" => $email,
                    "phone" => $phone,
                    "verified_email" => $verifiedEmail,
                    "addresses" => $addresses
                ]
            ]
        );

        $body = $response->getDecodedBody();

        if(isset($body['customer'])) {
            $customerId = $body['customer']['id'];
        }

        return $customerId;
    }

    public function findCustomer($email, $shopifyStoreUrl, $accessToken)
    {
        $foundCustomer = null;
        $client = new Rest($shopifyStoreUrl, $accessToken);
        $response = $client->get("customers");
        $body = $response->getDecodedBody();

        foreach($body['customers'] as $customer) {
            if($customer['email'] == $email) {
                $foundCustomer = $customer;
            }
        }

        return $foundCustomer;
    }
}
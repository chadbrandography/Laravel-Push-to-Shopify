<?php
namespace App\Http\Controllers\Api\V1\Fireside;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Shopify\Clients\Rest;
use App\Helpers\ShopifyApi;
use App\Helpers\FiresideApi;
use App\Helpers\FiresideShopifyProducts;

class ProductController extends Controller
{
    /**
     * Sync product inventory for fireside
     * Returns json string
     */
    public function sync(Request $request)
    {
        set_time_limit(0);
        //ini_set('max_execution_time', '300');

        $message = "";
        try {
            $input = $request->all();

            $authToken = (new FiresideApi())->getToken();
            $productCatalog = (new FiresideApi())->getProductCatalog($authToken);
            $results = (new FiresideShopifyProducts())->syncProducts($productCatalog);

            $message = "Product Sync Done";
        } catch (\Exception $e) {
            $message = 'Caught exception: ' . $e->getMessage();
        }

        return response()->json([
            'message' => $message,
            'results' => $results
        ]);
    }
}
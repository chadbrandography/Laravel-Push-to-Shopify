<?php
namespace App\Helpers;

use Shopify\Context;
use Shopify\Auth\FileSessionStorage;
use App\Helpers\ShopifyApi;
use App\Helpers\FiresideMetafields;
use Shopify\Clients\Rest;

class FiresideShopifyProducts
{
    /**
     * Start the sync product process
     * Returns string of messages
     */
    public function syncProducts($productCatalog)
    {
        $results = "";

        try {
            $dealers = $productCatalog->HHT->DealerInfo->Dealers;
            $products = $productCatalog->HHT->Lookups->Products;

            $shopifyProducts = $this->getShopifyProducts();

            // dd(count($shopifyProducts['products']));

            $this->upsertProducts($products, $dealers, $shopifyProducts);
            $results = "Done Upserting Products";
        } catch (\Exception $e) {
            $results = 'Caught exception: ' . $e->getMessage();
        }

        return $results;
    }

    /**
     * Get products list from shopify
     * Returns json object
     */
    public function getShopifyProducts()
    {
        $shopifyStore = 'fireside';
        $shopifyStoreUrl = config('app.' . $shopifyStore . '_shopify_url');
        $accessToken = config('app.' . $shopifyStore . '_shopify_access_token');
        $apiKey = config('app.' . $shopifyStore . '_shopify_api_key');
        $apiSecret = config('app.' . $shopifyStore . '_shopify_api_secret_key');
        $apiVersion = config('app.' . $shopifyStore . '_api_version');
        (new ShopifyApi())->setShopifyContext($apiKey, $apiSecret, $shopifyStoreUrl, $apiVersion);

        $client = new Rest($shopifyStoreUrl, $accessToken);
        $response = $client->get("products", [], ["limit" => 250]);
        $body = $response->getDecodedBody();

        return $body;
    }

    /**
     * Update or insert new products accordingly
     */
    public function upsertProducts($products, $dealers, $shopifyProducts)
    {
        $shopifyStore = 'fireside';

        $shopifyStoreUrl = config('app.' . $shopifyStore . '_shopify_url');
        $accessToken = config('app.' . $shopifyStore . '_shopify_access_token');
        $apiKey = config('app.' . $shopifyStore . '_shopify_api_key');
        $apiSecret = config('app.' . $shopifyStore . '_shopify_api_secret_key');
        $apiVersion = config('app.' . $shopifyStore . '_api_version');
        (new ShopifyApi())->setShopifyContext($apiKey, $apiSecret, $shopifyStoreUrl, $apiVersion);

        $productsLooped = 0;
        $productsUpserted = 0;
        $productLimit = 500;
        $productArray = [];
        foreach($products as $product)
        {
            if(!in_array($this->createSlug($product->ProductName), $productArray)) {
                array_push($productArray, $this->createSlug($product->ProductName));
                $locationProfiles = "";
                if($productsLooped < $productLimit)
                {
                    $locationProfiles = $this->getLocationProfiles($dealers, $product->BrandCode);
                    $shopifyProduct = $this->checkForProduct($product, $shopifyProducts);

                    if($shopifyProduct == null)  {
                        $this->createShopifyProduct($product, $locationProfiles);
                    } else {
                        $this->updateShopifyProduct($product, $shopifyProduct, $locationProfiles);
                    }

                    $productsUpserted++;
                }

                $productsLooped++;
            }
        }
    }

    public function createSlug($string) {
        $table = array(
            'Š'=>'S', 'š'=>'s', 'Đ'=>'Dj', 'đ'=>'dj', 'Ž'=>'Z', 'ž'=>'z', 'Č'=>'C', 'č'=>'c', 'Ć'=>'C', 'ć'=>'c',
            'À'=>'A', 'Á'=>'A', 'Â'=>'A', 'Ã'=>'A', 'Ä'=>'A', 'Å'=>'A', 'Æ'=>'A', 'Ç'=>'C', 'È'=>'E', 'É'=>'E',
            'Ê'=>'E', 'Ë'=>'E', 'Ì'=>'I', 'Í'=>'I', 'Î'=>'I', 'Ï'=>'I', 'Ñ'=>'N', 'Ò'=>'O', 'Ó'=>'O', 'Ô'=>'O',
            'Õ'=>'O', 'Ö'=>'O', 'Ø'=>'O', 'Ù'=>'U', 'Ú'=>'U', 'Û'=>'U', 'Ü'=>'U', 'Ý'=>'Y', 'Þ'=>'B', 'ß'=>'Ss',
            'à'=>'a', 'á'=>'a', 'â'=>'a', 'ã'=>'a', 'ä'=>'a', 'å'=>'a', 'æ'=>'a', 'ç'=>'c', 'è'=>'e', 'é'=>'e',
            'ê'=>'e', 'ë'=>'e', 'ì'=>'i', 'í'=>'i', 'î'=>'i', 'ï'=>'i', 'ð'=>'o', 'ñ'=>'n', 'ò'=>'o', 'ó'=>'o',
            'ô'=>'o', 'õ'=>'o', 'ö'=>'o', 'ø'=>'o', 'ù'=>'u', 'ú'=>'u', 'û'=>'u', 'ý'=>'y', 'ý'=>'y', 'þ'=>'b',
            'ÿ'=>'y', 'Ŕ'=>'R', 'ŕ'=>'r', '/' => '-', ' ' => '-'
        );

        // -- Remove duplicated spaces
        $stripped = preg_replace(array('/\s{2,}/', '/[\t\n]/'), ' ', $string);

        // -- Returns the slug
        return strtolower(strtr($string, $table));
    }

    /**
     * Creates a shopify product
     * Returns string of result message
     */
    public function createShopifyProduct($product, $locationProfiles)
    {
        $shopifyStore = "fireside";
        $shopifyStoreUrl = config('app.' . $shopifyStore . '_shopify_url');
        $accessToken = config('app.' . $shopifyStore . '_shopify_access_token');
        $client = new Rest($shopifyStoreUrl, $accessToken);

        $imageLargeData = null;
        try {
            $imageLarge = file_get_contents($product->ImageLarge);
            if ($imageLarge !== false){
                $imageLargeData = base64_encode($imageLarge);
            }
        } catch (\Exception $e) {
            $imageLargeData = "";
        }

        $imageData = null;
        try{
            $image = file_get_contents($product->ListImage);
            if ($image !== false){
                $imageData = base64_encode($image);
            }
        } catch (\Exception $e) {
            $imageData = "";
        }

        $response = $client->post(
        "products",
            [
                "product" => [
                    "title" => $product->ProductName,
                    "body_html" => $product->ProductDescription,
                    "vendor" => $product->Brand,
                    "product_type" => $product->FuelType . " Fireplace",
                    "status" => "draft",
                    "variants" => [[
                        "title" => $product->ProductName,
                        "price"=> $product->MSRP
                    ]],
                    "images" => [
                        [
                            "attachment" => $imageLargeData
                        ],
                        [
                            "attachment" => $imageData
                        ]
                    ]
                ]
            ]
        );

        sleep(2);
        $shopifyProducts = $this->getShopifyProducts();
        $shopifyProduct = $this->checkForProduct($product, $shopifyProducts);
        if(isset($shopifyProduct['id'])) {
            (new FiresideMetafields())->setMetafields($client, $product, $shopifyProduct, $locationProfiles);
        }

        return $response->getReasonPhrase();
    }

    /**
     * Updates a shopify product
     * Returns string of results
     */
    function updateShopifyProduct($product, $shopifyProduct, $locationProfiles)
    {
        $shopifyStore = "fireside";
        $shopifyStoreUrl = config('app.' . $shopifyStore . '_shopify_url');
        $accessToken = config('app.' . $shopifyStore . '_shopify_access_token');
        $client = new Rest($shopifyStoreUrl, $accessToken);

        $productId = $shopifyProduct['id'];
        $body = [
            "product" => [
                "title" => $product->ProductName,
                "body_html" => $product->ProductDescription,
                "vendor" => $product->Brand,
            ]
        ];
        $response = $client->put(
            "products/$productId",
            $body,
        );

        // sleep(2);
        // if(isset($shopifyProduct['id'])) {
        //     (new FiresideMetafields())->setMetafields($client, $product, $shopifyProduct, $locationProfiles);
        // }

        return $response->getReasonPhrase();
    }

    /**
     * Check for product from shopify
     * Returns null or shopify product
     */
    public function checkForProduct($product, $shopifyProducts)
    {
        $productSearch = null;

        foreach($shopifyProducts['products'] as $productObject) {
            if($this->createSlug($product->ProductName) == $this->createSlug($productObject['title'])) {
                $productSearch = $productObject;
            }
        }

        return $productSearch;
    }

    /**
     * Process and get location profiles string based on product availability
     * Returns string
     */
    public function getLocationProfiles($dealers, $brandCode)
    {
        $locationProfileString = "";

        foreach($dealers as $dealer)
        {
            foreach($dealer->Brands as $brand)
            {
                if($brand->BrandCode == $brandCode)
                {
                    $locationString = $dealer->City . ", " . $dealer->State;
                    $locationProfileSlug = $this->getLocationProfileSlug($locationString);

                    if(strlen($locationProfileSlug) > 0 && strpos($locationProfileString, $locationProfileSlug) === false)
                        $locationProfileString .= $this->getLocationProfileSlug($locationString) . ",";
                }
            }
        }

        return substr_replace($locationProfileString, "", -1);
    }

    /**
     * Gets a location slug based on location of product availability
     * Returns string
     */
    public function getLocationProfileSlug($locationString)
    {
        $profileSlug =  "";

        $path = storage_path() . "/location_profiles.json";
        $locationProfiles = json_decode(file_get_contents($path));
        foreach($locationProfiles->profiles as $profile)
        {
            foreach($profile->locations as $location)
            {
                if($location->name == $locationString)
                    $profileSlug = $profile->slug;
            }
        }
        return $profileSlug;
    }
}
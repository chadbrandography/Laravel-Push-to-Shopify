<?php
namespace App\Helpers;

use Shopify\Context;
use Shopify\Auth\FileSessionStorage;

class FiresideMetafields
{
    /**
     * Set product metafields - unfortunately combining them in one call didn't work, it would only honor the first one, so we have to do them individually
     * Returns result string
     */
    public function setMetafields($client, $product, $shopifyProduct, $locationProfiles)
    {
        $filterType = $product->FuelType . " Fireplace";
        $filterProducttype = $product->FuelType . " Fireplace";
        $filterBrand = $product->Brand;
        $filterHeat = $product->FuelType;
        $filterFuelType = $product->FuelType;
        $filterStyle = $product->FuelType;
        $filterBuyonline = "No";

        //Add Product meta data
        $metaResponse = $client->post(
            "metafields",
                [
                    "metafield" => [
                        "owner_resource" => "product",
                        "owner_id" => $shopifyProduct['id'],
                        "product_id" => $shopifyProduct['id'],
                        "namespace" => "product",
                        "key" => "location_profiles",
                        "value" => $locationProfiles,
                        "type" => "single_line_text_field"
                    ]
                ]
            );
        $metaResponse = $client->post(
            "metafields",
                [
                    "metafield" => [
                        "owner_resource" => "product",
                        "owner_id" => $shopifyProduct['id'],
                        "product_id" => $shopifyProduct['id'],
                        "namespace" => "product_filter",
                        "key" => "type",
                        "value" => $filterType,
                        "type" => "single_line_text_field"
                    ]
                ]
            );
        $metaResponse = $client->post(
            "metafields",
                [
                    "metafield" => [
                        "owner_resource" => "product",
                        "owner_id" => $shopifyProduct['id'],
                        "product_id" => $shopifyProduct['id'],
                        "namespace" => "product_filter",
                        "key" => "producttype",
                        "value" => $filterProducttype,
                        "type" => "single_line_text_field"
                    ]
                ]
            );
        $metaResponse = $client->post(
            "metafields",
                [
                    "metafield" => [
                        "owner_resource" => "product",
                        "owner_id" => $shopifyProduct['id'],
                        "product_id" => $shopifyProduct['id'],
                        "namespace" => "product_filter",
                        "key" => "buyonline",
                        "value" => $filterBuyonline,
                        "type" => "single_line_text_field"
                    ]
                ]
            );
        $metaResponse = $client->post(
            "metafields",
                [
                    "metafield" => [
                        "owner_resource" => "product",
                        "owner_id" => $shopifyProduct['id'],
                        "product_id" => $shopifyProduct['id'],
                        "namespace" => "product_filter",
                        "key" => "fueltype",
                        "value" => $filterFuelType,
                        "type" => "single_line_text_field"
                    ]
                ]
            );
        $metaResponse = $client->post(
            "metafields",
                [
                    "metafield" => [
                        "owner_resource" => "product",
                        "owner_id" => $shopifyProduct['id'],
                        "product_id" => $shopifyProduct['id'],
                        "namespace" => "product_filter",
                        "key" => "style",
                        "value" => $filterStyle,
                        "type" => "single_line_text_field"
                    ]
                ]
            );
        $metaResponse = $client->post(
            "metafields",
                [
                    "metafield" => [
                        "owner_resource" => "product",
                        "owner_id" => $shopifyProduct['id'],
                        "product_id" => $shopifyProduct['id'],
                        "namespace" => "product_filter",
                        "key" => "heat",
                        "value" => $filterHeat,
                        "type" => "single_line_text_field"
                    ]
                ]
            );
        $metaResponse = $client->post(
            "metafields",
                [
                    "metafield" => [
                        "owner_resource" => "product",
                        "owner_id" => $shopifyProduct['id'],
                        "product_id" => $shopifyProduct['id'],
                        "namespace" => "product_filter",
                        "key" => "location",
                        "value" => "",
                        "type" => "single_line_text_field"
                    ]
                ]
            );
        $metaResponse = $client->post(
            "metafields",
                [
                    "metafield" => [
                        "owner_resource" => "product",
                        "owner_id" => $shopifyProduct['id'],
                        "product_id" => $shopifyProduct['id'],
                        "namespace" => "product_filter",
                        "key" => "brand",
                        "value" => $product->Brand,
                        "type" => "single_line_text_field"
                    ]
                ]
            );
        $downloadHtml = '<h4>CAD Drawings</h4>' . $product->CadDrawings . '<h4>Architect Guides</h4>' . $product->ArchitectGuides . '<h4>Installation Manuals</h4>' . $product->InstallationManuals . '<h4>Product Brochures</h4>' . $product->ProductBrochures . '<h4>Service Parts</h4>' . $product->ServiceParts . '';
        $metaResponse = $client->post(
            "metafields",
                [
                    "metafield" => [
                        "owner_resource" => "product",
                        "owner_id" => $shopifyProduct['id'],
                        "product_id" => $shopifyProduct['id'],
                        "namespace" => "product",
                        "key" => "downloads",
                        "value" => $downloadHtml,
                        "type" => "multi_line_text_field"
                    ]
                ]
            );
            $metaResponse = $client->post(
                "metafields",
                    [
                        "metafield" => [
                            "owner_resource" => "product",
                            "owner_id" => $shopifyProduct['id'],
                            "product_id" => $shopifyProduct['id'],
                            "namespace" => "product",
                            "key" => "specification_charts",
                            "value" => $product->SpecificationsChart,
                            "type" => "multi_line_text_field"
                        ]
                    ]
                );
        $metaResponse = $client->post(
            "metafields",
                [
                    "metafield" => [
                        "owner_resource" => "product",
                        "owner_id" => $shopifyProduct['id'],
                        "product_id" => $shopifyProduct['id'],
                        "namespace" => "product",
                        "key" => "features",
                        "value" => "",
                        "type" => "multi_line_text_field"
                    ]
                ]
            );

        return $metaResponse->getReasonPhrase();
    }
}
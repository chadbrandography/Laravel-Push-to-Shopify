<?php
namespace App\Helpers;

use Shopify\Context;
use Shopify\Auth\FileSessionStorage;

class ShopifyApi
{
    public function setShopifyContext($apiKey, $apiSecret, $shopifyStoreUrl, $apiVersion)
    {
        Context::initialize(
            $apiKey,
            $apiSecret,
            'write_customers, read_customers, write_draft_orders, read_draft_orders, write_products, read_products',
            $shopifyStoreUrl,
            new \Shopify\Auth\FileSessionStorage('/tmp/php_sessions'),
            $apiVersion,
            true,
            false,
        );
    }

}
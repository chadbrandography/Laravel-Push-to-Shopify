<?php
namespace App\Helpers;

use Mail;

class QualificationTargetsNotifications
{
    public function sendNotification($input)
    {
        $emailTos = ["steve@brandography.com"];
        if(config('app.env') == "production") {
            $emailTos = ["bjgulick@targets.net", "sales@targets.net", "accounting@targets.net"];
        }

        $data = array(
            'data' => $input
        );
        Mail::send('email-basic', $data, function ($message) use($emailTos) {
            $message->from(config('mail.from.address'), 'Qualification Targets');
            $message->to($emailTos)->subject('New Draft Order');
        });
    }
}
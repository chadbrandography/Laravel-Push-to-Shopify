<?php

namespace App\Helpers;

use Shopify\Context;
use Shopify\Auth\FileSessionStorage;
use Mail;

class FiresideLead
{
    public function submitLead($input)
    {
        //figure out who to send it to
        $emailTos = [];

        $zip = $input['zip'];

        $path = storage_path() . "/location_profiles.json";
        $locationProfiles = json_decode(file_get_contents($path));

        foreach ($locationProfiles->profiles as $profile) {
            $zip_codes = $profile->zip_codes;
            if (strpos($zip_codes, $zip) !== false) {
                foreach ($profile->locations as $location) {
                    array_push($emailTos, $this->getLeadEmail($location->slug));
                }
            }
        }
        $emailTos = array_unique($emailTos);

        // $emailTos = ["steve@brandography.com"]; //debugging leads won't go live yet

        if (count($emailTos) == 0) {
            array_push($emailTos, 'rethlakee@fireside.com', 'rethlakee@hearthnhome.com', 'elyse@elyserethlake.com', 'britt@brandography.com');
        }

        if (count($emailTos) > 0) {
            $data = array(
                'data' => $input
            );
            Mail::send('email', $data, function ($message) use ($emailTos) {
                $message->from(config('mail.from.address'), 'Web Lead');
                $message->to($emailTos)->subject('Fireside Lead');
            });
        }
    }

    public function getLeadEmail($locationSlug)
    {
        $leadLocationEmails = [];
        $leadLocationEmails["eagan-mn"] = "hoffmana@fireside.com";
        $leadLocationEmails["eden-prairie-mn"] = "denissenc@fireside.com";
        $leadLocationEmails["maple-grove-mn"] = "denissenc@fireside.com";
        $leadLocationEmails["minnetonka-mn"] = "denissenc@fireside.com";
        $leadLocationEmails["roseville-mn"] = "hoffmana@fireside.com";
        $leadLocationEmails["madison-wi"] = "vossj@fireside.com";
        $leadLocationEmails["elkridge-md"] = "hlatkyd@fireside.com";
        $leadLocationEmails["raleigh-nc"] = "buntingj@fireside.com";
        $leadLocationEmails["chantilly-va"] = "hlatkyd@fireside.com";
        $leadLocationEmails["nashville-tn"] = "murphypa@fireside.com";
        $leadLocationEmails["bridgeville-de"] = "setreed@fireside.com";
        $leadLocationEmails["charlotte-nc"] = "buntingj@fireside.com";
        $leadLocationEmails["greensboro-nc"] = "buntingj@fireside.com";
        $leadLocationEmails["wilmington-nc"] = "buntingj@fireside.com";
        $leadLocationEmails["robbinsville-nj"] = "fanellip@fireside.com";
        $leadLocationEmails["goshen-ny"] = "fanellip@fireside.com";
        $leadLocationEmails["limerick-pa"] = "setreed@fireside.com";
        $leadLocationEmails["york-pa"] = "setreed@fireside.com";
        $leadLocationEmails["charleston-sc"] = "buntingj@fireside.com";
        $leadLocationEmails["columbia-sc"] = "buntingj@fireside.com";
        $leadLocationEmails["greenville-sc"] = "buntingj@fireside.com";
        $leadLocationEmails["myrtle-beach-sc"] = "buntingj@fireside.com";
        $leadLocationEmails["knoxville-tn"] = "smithjoshu@fireside.com";
        $leadLocationEmails["charlottesville-va"] = "hallje@fireside.com";
        $leadLocationEmails["newport-news-va"] = "hallje@fireside.com";
        $leadLocationEmails["richmond-va"] = "hallje@fireside.com";
        $leadLocationEmails["dallas-tx"] = "stamppm@fireside.com";

        return $leadLocationEmails[$locationSlug];
    }
}

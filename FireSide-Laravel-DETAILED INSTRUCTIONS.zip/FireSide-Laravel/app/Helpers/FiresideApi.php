<?php
namespace App\Helpers;

class FiresideApi
{
    /**
     * Get fireside api token
     * Returns string
     */
    public function getToken()
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => config('app.fireside_api_url') . '/Token',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => 'grant_type=' . config('app.fireside_token_grant_type') . '&username=' . config('app.fireside_token_username') . '&password=' . config('app.fireside_token_password') . '',
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/x-www-form-urlencoded',
            ),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $tokenRequestObject = json_decode($response);

        return $tokenRequestObject->access_token;
    }

    /**
     * Get fireside product catalog
     * Returns json object
     */
    public function getProductCatalog($authToken)
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => config('app.fireside_api_url') . '/api/Syndication/GetProductCatalog',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => 'PartnerId=' . config('app.fireside_api_partner_id'),
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer ' . $authToken,
                'Content-Type: application/x-www-form-urlencoded',
            ),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        $productCatalog = json_decode($response);

        return $productCatalog;
    }
}
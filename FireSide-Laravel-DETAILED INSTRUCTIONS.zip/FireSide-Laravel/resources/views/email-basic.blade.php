<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="utf-8">
</head>
<body>
    <h2>New Draft Order</h2>
    @if(isset($data))
    <div>
        <p>
            A New Draft Order has been created for: <br />
            <strong>First Name: </strong>{{ $data['first_name'] }}<br />
            <strong>Last Name: </strong>{{ $data['last_name'] }}<br />
            <strong>Email: </strong>{{ $data['email'] }}<br />
            <strong>Phone: </strong>{{ $data['phone'] }}<br />
            <strong>Address: </strong>{{ $data['address1'] }}<br />
            <strong>City: </strong>{{ $data['city'] }}<br />
            <strong>State: </strong>{{ $data['state'] }}<br />
            <strong>Zip: </strong>{{ $data['zip'] }}<br />
            <strong>Purchase Order Number: </strong>{{ $data['po_number'] }}<br />
        </p>

    </div>
    @endif
</body>
</html>
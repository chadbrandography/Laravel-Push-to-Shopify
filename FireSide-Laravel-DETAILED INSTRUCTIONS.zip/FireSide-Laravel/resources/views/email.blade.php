<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="utf-8">
</head>
<body>
    <h2>Fireside Lead</h2>
    @if(isset($data))
    <div>

        <p>
            <strong>First Name: </strong>{{ $data['first_name'] }}<br />
            <strong>Last Name: </strong>{{ $data['last_name'] }}<br />
            <strong>Email: </strong>{{ $data['email'] }}<br />
            <strong>Phone: </strong>{{ $data['phone'] }}<br />
            <strong>Address: </strong>{{ $data['address1'] }}<br />
            <strong>City: </strong>{{ $data['city'] }}<br />
            <strong>State: </strong>{{ $data['state'] }}<br />
            <strong>Zip: </strong>{{ $data['zip'] }}<br />
            <strong>Lead Type: </strong>{{ $data['ima'] }}<br />
            <strong>Project Type: </strong>{{ $data['projectType'] }}<br />
            <strong>Project Timeline: </strong>{{ (isset($data['projectTimeline'])) ? $data['projectTimeline'] : "N/A" }}<br />
            <strong>Project Details: </strong>{{ $data['projectDetails'] }}<br />
            <strong>Contractor Name(if applicable): </strong>{{ $data['contactorName'] }}<br />
            <strong>Company Name(if applicable): </strong>{{ $data['companyName'] }}<br />
        </p>

    </div>
    @endif
</body>
</html>